import { render, screen } from '@testing-library/react';
import App from './com/App';

test('renders learn react link', () => {
  render(<App />);
});
